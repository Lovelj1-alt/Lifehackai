// Netlify Function: /api/ask
// Reads OPENAI_API_KEY (and optional OPENAI_MODEL) from environment
const DEFAULT_MODEL = process.env.OPENAI_MODEL || 'gpt-4o-mini';

exports.handler = async (event) => {
  // CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 204,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization',
        'Access-Control-Allow-Methods': 'POST, OPTIONS'
      },
      body: ''
    };
  }

  if (event.httpMethod !== 'POST') {
    return { statusCode: 405, body: 'Method Not Allowed' };
  }

  try {
    const { prompt } = JSON.parse(event.body || '{}');
    if (!prompt) {
      return { statusCode: 400, body: 'Missing prompt' };
    }
    if (!process.env.OPENAI_API_KEY) {
      return { statusCode: 500, body: 'Server missing OPENAI_API_KEY' };
    }

    // Call OpenAI Chat Completions API
    const resp = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: DEFAULT_MODEL,
        messages: [
          { role: 'system', content: 'You are Lifehackai, a concise, practical assistant for prompts, side hustles, and fast execution.' },
          { role: 'user', content: prompt }
        ],
        temperature: 0.5
      })
    });

    if (!resp.ok) {
      const text = await resp.text();
      return { statusCode: 502, body: `Upstream error: ${text}` };
    }

    const data = await resp.json();
    const reply = data.choices?.[0]?.message?.content || '(no content)';
    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
      body: JSON.stringify({ reply })
    };
  } catch (err) {
    return { statusCode: 500, body: 'Error: ' + err.message };
  }
};
