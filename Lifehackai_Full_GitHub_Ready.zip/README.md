# Lifehackai

A lightweight, PWA‑ready web app for prompt packs, fast ideation, and one‑tap AI helpers. Deployable on Netlify with a serverless function that proxies to OpenAI.

## Quick Start

**Manual Deploy (fastest)**
1. Drag-and-drop this folder into Netlify → *Add new site → Deploy manually*.
2. In **Site configuration → Environment variables**, add `OPENAI_API_KEY`.
3. Visit your site → Share → **Add to Home Screen** on iPhone.

**GitHub Deploy (auto updates)**
1. Push this folder to a new GitHub repo.
2. In Netlify → *Add new site → Import from Git* → pick your repo.
3. Build settings: Build command *(empty)*, Publish directory `/`.
4. Add `OPENAI_API_KEY` (and optional `OPENAI_MODEL`) in *Environment variables*.

## Project Structure

```
/assets              # icons + logo
/netlify/functions   # serverless function: ask.js
index.html           # app shell
styles.css           # styles
script.js            # logic (packs, search, chat)
packs.json           # content packs
manifest.json        # PWA manifest
service-worker.js    # offline caching
netlify.toml         # Netlify config + redirects
```

## Configure the Chat Endpoint

- Set `OPENAI_API_KEY` in Netlify → Site configuration → Environment variables.
- Optional: set `OPENAI_MODEL` (defaults to `gpt-4o-mini`).

**Local note:** The function runs only on Netlify (or `netlify dev`). Static preview without the key will still load prompt packs and UI.

## Custom Domain (IONOS → Netlify)

- Add domain in Netlify → Domain Management.
- In IONOS DNS, set:
  - `A` @ → `75.2.60.5`, `99.83.229.8`
  - `CNAME` www → your-site.netlify.app
- Back in Netlify, Verify DNS → Enable HTTPS.

## License

MIT © 2025 Lifehackai
