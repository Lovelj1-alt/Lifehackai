# Lifehackai
PWA + prompt packs + Netlify Function.

## Quick Links
- Open GitHub → New repo: https://github.com/new
- Netlify dashboard: https://app.netlify.com

## Upload to GitHub
1) Create repo `lifehackai` (public).  
2) Upload all files from this folder (keep `.github/workflows`).  
3) Commit.

## Netlify (Import from Git)
- Build command: (empty)
- Publish directory: /
- Env var: OPENAI_API_KEY (and optional OPENAI_MODEL)
